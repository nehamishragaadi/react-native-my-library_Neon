//
//  SelectImgCameraCollectionViewCell.swift
//  Neon-Ios
//
//  Created by Neha Mishra1 on 4/11/19.
//  Copyright © 2019 Girnar. All rights reserved.
//

import UIKit

class SelectImgCameraCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var tag_Name: UITextField!
    @IBOutlet weak var selectImage: UIImageView!
}
