//
//  NeutralModel.swift
//  Neon-Ios
//
//  Created by Girnar on 08/02/19.
//  Copyright © 2019 Girnar. All rights reserved.
//

import Foundation
class NeutralModel{
    func setParams(iParam : INeutralParam) -> PhotosModel{
        return PhotosModel(params: iParam)
    }
}
