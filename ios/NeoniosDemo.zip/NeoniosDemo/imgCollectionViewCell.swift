//
//  imgCollectionViewCell.swift
//  Neon-Ios
//
//  Created by Temp on 23/08/19.
//  Copyright © 2019 Girnar. All rights reserved.
//

import UIKit

class imgCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}
