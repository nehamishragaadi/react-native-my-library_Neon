//
//  ResponseCode.swift
//  Neon-Ios
//
//  Created by Girnar on 2/5/19.
//  Copyright © 2019 Girnar. All rights reserved.
//

import Foundation
enum ResponseCode {
    case Back
    case Success
    case Camera_Permission_Error
    case Write_Permission_Error
    case UnknownFailure
    
}
