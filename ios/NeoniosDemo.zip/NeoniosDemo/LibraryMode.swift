//
//  LibraryMode.swift
//  Neon-Ios
//
//  Created by Girnar on 07/02/19.
//  Copyright © 2019 Girnar. All rights reserved.
//

import Foundation
enum LibraryMode: Int, Codable {
    case Restrict
    case Relax
}
