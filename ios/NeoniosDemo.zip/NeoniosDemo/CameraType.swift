//
//  CameraType.swift
//  Neon-Ios
//
//  Created by Girnar on 07/02/19.
//  Copyright © 2019 Girnar. All rights reserved.
//

import Foundation
enum CameraType: Int, Codable {
    case normal_camera
    case gallery_preview_camera
}

